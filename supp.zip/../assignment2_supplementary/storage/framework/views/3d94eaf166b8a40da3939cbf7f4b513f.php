<?php $__env->startSection('content'); ?>

<div class='container'>
    <div class='row mb-1'>&nbsp;</div>

    <div class='row'>
    <div class='col-2'><a href="<?php echo e(route('restaurants.show',['id' => $dish->user_id])); ?>" class="btn btn-secondary m-2 p-2"><b><h6>< &nbsp; Back</h6></b></a></div>
        <div class='col-8 text-center'>
            <h2><u>Edit Dish</u></h2>
        </div>
        <div class='col-2'>&nbsp;</div>
    </div>

    <div class='row'>
        <!-- Form for editing dish details -->
        <div class='col-2 mb-3'>&nbsp;</div>
        <div class='col-8'>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <p><strong>Error: There was some issues with your entered values.</strong></p>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                    <p><strong>Entered Values:</strong></p>
                    <ul>
                        <li><strong>Name:</strong> <?php echo e(old('name', $dish->name)); ?></li>
                        <li><strong>Description:</strong> <?php echo e(old('description', $dish->description)); ?></li>
                        <li><strong>Price:</strong> <?php echo e(old('price', $dish->price)); ?></li>
                    </ul>


                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('dishes.update', ['id' => $dish->id])); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>

                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo e($dish->name); ?>">
                </div>

                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea class="form-control" id="description" name="description"><?php echo e($dish->description); ?></textarea>
                </div>

                <div class="form-group">
                    <label for="price">Price</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">$</span>
                            </div>
                            <input type="text" class="form-control" id="price" name="price" value="<?php echo e($dish->price); ?>">
                        </div>
                    </div>
                <button type="submit" class="btn btn-primary">Update Dish</button>
            </form>
        </div>
        <div class='col-2'>&nbsp;</div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/2703ICT/Assignment2_Supplementary/assignment2_supplementary/resources/views/editDish.blade.php ENDPATH**/ ?>