<?php $__env->startSection('content'); ?>

<div class='container'>

    <div class='row mb-1'>&nbsp;</div>

    <div class='row'>
        <div class='col-4'><a href="<?php echo e(route('restaurants.show', ['id' => auth()->id()])); ?>" class="btn btn-secondary m-2 p-2"><b><h6>< &nbsp; Back</h6></b></a></div>
        <div class='col-4 text-center'>
            <h2><u>Add New Dish</u></h2>
        </div>
        <div class='col-4'>&nbsp;</div>
    </div>

    <div class='row'>
        <div class='col-2'>&nbsp;</div>
        <div class='col-8 text-center'><h4><?php echo e(auth()->user()->name); ?></h4></div>
        <div class='col-2'>&nbsp;</div>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <p><strong>Error: There was some issues with your entered values.</strong></p>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

            <p><strong>Entered Values:</strong></p>
            <ul>
                <li><strong>Name:</strong> <?php echo e(old('name')); ?></li>
                <li><strong>Description:</strong> <?php echo e(old('description')); ?></li>
                <li><strong>Price:</strong> <?php echo e(old('price')); ?></li>
            </ul>


        </div>
    <?php endif; ?>

    <div class='row'>
        <div class='col-1'>&nbsp;</div>
        <div class='col-10'>
            <form action="<?php echo e(route('dishes.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <label for="name">Dish Name</label>
                    <input type="text" name="name" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea name="description" class="form-control"></textarea>
                </div>
                <div class="form-group">
                    <label for="price">Price</label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text">$</span>
                        </div>
                        <input type="text" name="price" class="form-control" required>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary p-2">Add Dish</button>
            </form>
        </div>
        <div class='col-1'>&nbsp;</div>
    </div>
    
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/2703ICT/Assignment2_Supplementary/assignment2_supplementary/resources/views/addDish.blade.php ENDPATH**/ ?>