<?php $__env->startSection('content'); ?>


<div class='container'>

    <div class='row mb-3'>&nbsp;</div>

    <div class='row'>
        <div class='col-4'><a href="<?php echo e(route('restaurantList')); ?>" class="btn btn-secondary m-2 p-2"><b><h6>< &nbsp; Back</h6></b></a></div>
        <div class='col-4 text-center'>
            <h2><u><?php echo e($user->name); ?></u></h2>
            <h5><?php echo e($user->address); ?></h5>
        </div>
        <div class='col-4'>
            <div class='row'>
            <?php if(auth()->check() && auth()->user()->user_type === 'restaurant' && auth()->user()->id === $user->id): ?>
                <div class='col-6'>
                    <a href="<?php echo e(route('dishes.create')); ?>" style="text-decoration: none; color: inherit;">
                        <div class='btn btn-secondary m-2 p-2'><b><h6>Add Dish</h6></b></div>
                    </a>   
                </div>    

                <div class='col-6'>
                    <a href="<?php echo e(route('restaurant.orders', ['id' => $user->id])); ?>" style="text-decoration: none; color: inherit;">
                        <div class='btn btn-primary m-2 p-2'>
                            <b><h6>List of Orders</h6></b>
                        </div>
                    </a>    
                </div> 
            <?php endif; ?>
            </div>
        </div>
    </div>

    <div class='row mb-1'>&nbsp;</div>

    <?php if($user->user_type === 'restaurant'): ?>
    <?php $__currentLoopData = $user->dishes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dish): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-12">
        <a href="<?php echo e(route('dish.detail', ['id' => $dish->id])); ?>" style="text-decoration: none; color: inherit;">
            <div class="card shadow w-100" style="background-color: #81AE9D; color: white;">
                <div class="card-body">
                    <div class='row'>
                        <div class='col-4'>
                            <h3 class="card-title"><?php echo e($dish->name); ?></h3>
                        </div>
                        <div class='col-6'>&nbsp;</div>
                        <div class='col-2'><h3 class='font-weight-bold'>$<?php echo e($dish->price); ?></h3></div>
                    </div>
                </div>
            </div>
        </div>
        </a>
        <div class='row mb-1'>&nbsp;</div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div class="col-md-12">
            <div class="alert alert-info" role="alert">
                <?php echo e($user->name); ?> is not a restaurant user.
            </div>
        </div>
    <?php endif; ?>

</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/2703ICT/Assignment2_Supplementary/assignment2_supplementary/resources/views/restaurantDetail.blade.php ENDPATH**/ ?>